# 04_nav_data.rpy
# Node graph for the street-view-style tap-to-move navigation, ported
# directly from the Scratch project's node list/exit logic.
#
# SCOPE: apartment interior only. Nodes outside the apartment (Street, City,
# Temple, etc.) are not part of this step -- Apartment_Exterior exists here
# only as the front-door node, and its "forward" exit is left as None on
# purpose (it'll connect to the outside world in a later step).
#
# Each node has:
#   "bg"    - the Ren'Py image tag to display full-screen at this node
#   "exits" - one key per direction (left/right/forward/backward), mapping to
#             the node name to travel to, or None if there's no exit that way
#             (matches the Scratch project's "-" dashes exactly).

define nav_nodes = {

    "Bedroom": {
        "bg": "bg_bedroom",
        "exits": {"left": None, "right": None, "forward": None, "backward": "Livingroom"},
    },

    "Futon_Room": {
        "bg": "bg_futon_room",
        "exits": {"left": None, "right": None, "forward": None, "backward": "Bedroom"},
    },

    "Livingroom": {
        "bg": "bg_livingroom",
        "exits": {"left": "Bathroom", "right": "Front_Hallway", "forward": "Kitchen", "backward": "Bedroom"},
    },

    "Bathroom": {
        "bg": "bg_bathroom",
        "exits": {"left": None, "right": None, "forward": None, "backward": "Livingroom"},
    },

    "Front_Hallway": {
        "bg": "bg_front_hallway",
        "exits": {"left": None, "right": None, "forward": "Apartment_Exterior", "backward": "Livingroom"},
    },

    "Sitting_Room": {
        "bg": "bg_sitting_room",
        "exits": {"left": None, "right": None, "forward": "Kitchen", "backward": "Livingroom"},
    },

    "Kitchen": {
        "bg": "bg_kitchen",
        "exits": {"left": None, "right": None, "forward": None, "backward": "Livingroom"},
    },

    "Apartment_Exterior": {
        "bg": "bg_apartment_exterior",
        # Forward intentionally left disconnected -- leads further outside in
        # a later step, not part of this one.
        "exits": {"left": None, "right": None, "forward": None, "backward": "Front_Hallway"},
    },

}

# NOTE: Sitting_Room isn't reachable from any node in the graph as given
# (nothing in the table points into it -- Livingroom's exits are Bathroom /
# Front_Hallway / Kitchen / Bedroom, not Sitting_Room). It's included above
# exactly as specified, in case it's wired in from elsewhere (e.g. a doorway
# not modeled as one of the four directions) or is meant to be connected in a
# later pass -- flagging rather than silently changing the graph.
