# 01b_main_menu.rpy
# THIS SCREEN WAS MISSING BEFORE. Ren'Py's boot process always shows a
# screen literally named "main_menu" first -- without one defined anywhere,
# the game would error immediately on launch, before anything else in the
# project ever ran. That's almost certainly the actual reason nothing showed
# up in JoiPlay: there was no valid entry point at all.
#
# Uses the real Btn_Start/Btn_Settings/Btn_Quit art and MenuBackground art
# pulled from the Scratch project, scaled 3x like everything else (native
# art is 480x360 / 600x113, canvas is the 1920x1080 locked in by
# 00_options.rpy).

image menu_bg = "menu/menu_bg.png"


screen main_menu():

    tag menu

    add "menu_bg" at bg_fit

    vbox:
        xalign 0.5
        yalign 0.62
        spacing 30

        imagebutton:
            idle "menu/btn_start_idle.png"
            hover "menu/btn_start_hover.png"
            action Start()

        imagebutton:
            idle "menu/btn_settings_idle.png"
            hover "menu/btn_settings_hover.png"
            action ShowMenu("preferences_simple")

        imagebutton:
            idle "menu/btn_quit_idle.png"
            hover "menu/btn_quit_hover.png"
            action Quit(confirm=False)


## Minimal placeholder preferences screen -- Btn_Settings needs to go
## *somewhere*, and a full gui.rpy-style preferences screen wasn't in scope
## for this step. Replace with a real one later; this just keeps Settings
## from being a dead/crashing button.
screen preferences_simple():

    frame:
        background "gui/textbox.png"
        xalign 0.5
        yalign 0.5
        xsize 900
        ysize 500
        padding (60, 60, 60, 60)

        vbox:
            spacing 20
            text "Settings" size 40 color "#FFFFFF" bold True
            text "(placeholder -- real settings screen not built yet)" size 28 color "#CCCCCC"

            textbutton "Back":
                text_size 32
                text_color "#FFFFFF"
                action Return()
