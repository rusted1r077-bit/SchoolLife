# 06_nav_selftest.rpy
# Automated check that the node graph in 04_nav_data.rpy is wired correctly.
#
# I can't launch the actual Ren'Py engine in this environment to click
# through the arrows by hand, so this walks the exact loop requested --
# Bedroom -> Livingroom -> Front_Hallway -> Apartment_Exterior ->
# back to Front_Hallway -> Livingroom -- against the nav_nodes dict itself
# and asserts it lands on the right node at every step. It's cheap to keep
# around as a regression check after later edits to the graph, but it does
# NOT replace an actual click-through test of "apartment_explore" in the
# Ren'Py launcher -- please run that yourself once this is dropped in.

label apartment_nav_selftest:

    python:
        _expected_path = [
            "Bedroom", "Livingroom", "Front_Hallway",
            "Apartment_Exterior", "Front_Hallway", "Livingroom",
        ]
        _moves = ["backward", "right", "forward", "backward", "backward"]

        _node = "Bedroom"
        _trace = [_node]

        for _move in _moves:
            _target = nav_nodes[_node]["exits"][_move]
            if _target is None:
                raise Exception("Self-test failed: %s has no exit %s" % (_node, _move))
            _node = _target
            _trace.append(_node)

        if _trace != _expected_path:
            raise Exception("Self-test failed: got %r, expected %r" % (_trace, _expected_path))

        _selftest_result = " -> ".join(_trace)

    "Nav self-test passed:\n[_selftest_result]"

    return
