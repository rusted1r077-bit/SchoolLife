# 07_gamestate.rpy
# Core time/day/money state, ported from the Scratch project's Stage
# variables (GameMinutes, HasEaten, HasShowered, HasDressed, PlayerMoney).
#
# Scope: state + HUD only -- no scripted sequences (door/shower/sleep) yet.

## Persistent state variables #################################################
# All plain `default` variables, so they save/load/rollback with the rest of
# the game (see the same note on "persistent" vs `default` in
# 05_nav_screen.rpy -- this is the correct tool for state that should track
# per-playthrough, not Ren'Py's separate `persistent.` object).

default game_minutes = 420        # 420 = 7:00 AM on Day 1, matches the Scratch default
default has_eaten = False
default has_showered = False
default has_dressed = False
default player_money = 800        # matches the Scratch project's actual PlayerMoney start value (not a guess)


## Derived-value helpers #######################################################
# Day/hour/minute/time-of-day are never stored separately -- they're always
# computed live from game_minutes so they can't drift out of sync with it.

init python:

    def get_current_day():
        """1-indexed day number. 1440 minutes/day, matches the Scratch formula."""
        return (game_minutes // 1440) + 1

    def get_current_hour():
        """0-23 hour of the current day."""
        return (game_minutes // 60) % 24

    def get_current_minute():
        """0-59 minute within the current hour."""
        return game_minutes % 60

    def get_time_of_day():
        """Morning / Afternoon / Evening / Night bucket, derived from the hour.

        Boundaries (adjust later if needed):
            Morning   06:00-11:59
            Afternoon 12:00-17:59
            Evening   18:00-20:59
            Night     21:00-05:59 (wraps past midnight)
        """
        hour = get_current_hour()

        if 6 <= hour <= 11:
            return "Morning"
        elif 12 <= hour <= 17:
            return "Afternoon"
        elif 18 <= hour <= 20:
            return "Evening"
        else:
            return "Night"

    def format_clock():
        """'7:00 AM' / '12:30 PM' style 12-hour clock string for the HUD."""
        hour = get_current_hour()
        minute = get_current_minute()

        suffix = "AM" if hour < 12 else "PM"
        display_hour = hour % 12
        if display_hour == 0:
            display_hour = 12

        return "%d:%02d %s" % (display_hour, minute, suffix)

    def advance_time(minutes):
        """Advance game_minutes by `minutes`. If doing so crosses into a new
        in-game day, resets the daily flags (has_eaten/has_showered/has_dressed)
        to False. player_money is untouched -- it persists across days.
        """
        global game_minutes, has_eaten, has_showered, has_dressed

        old_day = get_current_day()
        game_minutes += minutes
        new_day = get_current_day()

        if new_day != old_day:
            has_eaten = False
            has_showered = False
            has_dressed = False
