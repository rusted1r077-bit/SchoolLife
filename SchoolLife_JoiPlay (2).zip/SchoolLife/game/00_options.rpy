# 00_options.rpy
# Base project setup. THIS FILE WAS MISSING BEFORE -- none of the previous
# steps actually declared these, they just assumed a resolution in comments.
# This is the one place config.screen_width/height get set for real; every
# zoom/xalign/position number in the other files (02_dialogue_gui.rpy,
# 05_nav_screen.rpy, 08_hud.rpy) was written assuming exactly this.

define config.name = _("School Life")
define config.version = "0.1 (dev)"

define config.screen_width = 1920
define config.screen_height = 1080
