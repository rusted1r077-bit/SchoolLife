# 05_nav_screen.rpy
# Street-view-style tap-to-move navigation, apartment interior only.

## Background images for each node ###########################################

image bg_bedroom = "bg/apartment/bedroom.png"
image bg_futon_room = "bg/apartment/futon_room.png"
image bg_livingroom = "bg/apartment/livingroom.png"
image bg_bathroom = "bg/apartment/bathroom.png"
image bg_sitting_room = "bg/apartment/sitting_room.png"
image bg_kitchen = "bg/apartment/kitchen.png"
image bg_apartment_exterior = "bg/apartment/apartment_exterior.png"

# PLACEHOLDER: no clean source art for Front_Hallway (see the note in
# 04_nav_data.rpy) -- swap this for real art in a later pass.
image bg_front_hallway = "bg/apartment/front_hallway_placeholder.png"


## Current-node tracking #####################################################

# Note on "persistent": this uses Ren'Py's `default` statement, which makes
# current_node a normal game variable that's saved/loaded/rolled-back with
# the rest of the game state -- i.e. it "carries through the game" the way
# player position should. Ren'Py also has a separate `persistent.` object,
# but that's for data that survives *across different save files* (settings,
# unlocks, etc.), which would be the wrong tool for "what room am I in" --
# flagging this in case "persistent variable" meant that instead.
default current_node = "Bedroom"


## Nav arrow screen ###########################################################
# Reusable for every node: reads nav_nodes[node]["exits"] and only shows the
# arrows that node actually has, positioned at the screen edges (forward/back
# top-and-bottom-center, left/right at the side edges), matching the layout
# implied by the original Scratch project's arrow sprite positions.

screen apartment_nav_arrows(node):

    $ exits = nav_nodes[node]["exits"]

    if exits["left"]:
        imagebutton:
            idle "nav/arrow_left.png"
            hover "nav/arrow_left_hover.png"
            xalign 0.03
            yalign 0.5
            at Transform(zoom=1.5)
            action Return("left")

    if exits["right"]:
        imagebutton:
            idle "nav/arrow_right.png"
            hover "nav/arrow_right_hover.png"
            xalign 0.97
            yalign 0.5
            at Transform(zoom=1.5)
            action Return("right")

    if exits["forward"]:
        imagebutton:
            idle "nav/arrow_forward.png"
            hover "nav/arrow_forward_hover.png"
            xalign 0.5
            yalign 0.06
            at Transform(zoom=1.5)
            action Return("forward")

    if exits["backward"]:
        imagebutton:
            idle "nav/arrow_backward.png"
            hover "nav/arrow_backward_hover.png"
            xalign 0.5
            yalign 0.94
            at Transform(zoom=1.5)
            action Return("backward")

    # Added when wiring up label start/dev hub: apartment_explore's loop has
    # no exit condition yet (see the note above it), so without this there
    # was no way to back out of it during testing except force-quitting.
    # Real exit conditions (an event, a menu choice) come in a later step.
    textbutton "Hub":
        xalign 0.01
        yalign 0.02
        text_size 26
        text_color "#FFFFFF"
        background "hud_chip_small"
        xsize 140
        ysize 60
        text_align 0.5
        action Return("__exit_to_hub__")


## Explore loop ###############################################################
# Shows the current node's background, waits for an arrow tap via
# renpy.call_screen (which blocks until an imagebutton Return()s a
# direction), moves to that exit's target node with a crossfade, and loops.
# Call this from anywhere with "call apartment_explore" once the apartment
# interior should be walkable.

# NOTE: this loop has no exit condition yet -- it's scoped to proving
# navigation works. A later step (game-state / scripted sequences) will add
# the actual way to break out of exploring (an event triggering, a menu
# option, etc.); for now "jump apartment_explore_loop" just keeps looping.

label apartment_explore:

    scene expression nav_nodes[current_node]["bg"] at bg_fit
    with dissolve

    jump apartment_explore_loop

label apartment_explore_loop:

    $ direction = renpy.call_screen("apartment_nav_arrows", node=current_node)

    if direction == "__exit_to_hub__":
        return

    $ target = nav_nodes[current_node]["exits"][direction]

    if target:
        $ current_node = target
        scene expression nav_nodes[current_node]["bg"] at bg_fit
        with dissolve

    jump apartment_explore_loop
