# 08_hud.rpy
# Gameplay HUD: day counter, clock, and money. Shown as an overlay during
# actual gameplay, hidden while on the main menu.

image hud_chip = "hud/hud_chip.png"
image hud_chip_small = "hud/hud_chip_small.png"
image icon_yen = "hud/icon_yen.png"

screen game_hud():

    zorder 100

    # `main_menu` is a built-in Ren'Py flag, True while the main menu screen
    # is showing -- this is what keeps the HUD off the main menu without
    # needing to manually show/hide it everywhere.
    if not main_menu:
        # Day + clock chip, top-left.
        frame:
            background "hud_chip"
            xpos 40
            ypos 40
            xsize 360
            ysize 90
            padding (30, 0, 30, 0)

            hbox:
                yalign 0.5
                spacing 24

                text "Day [get_current_day()]" size 32 color "#FFFFFF" bold True
                text "|" size 32 color "#7E5ECE"
                text "[format_clock()]" size 32 color "#FFFFFF" bold True

        # Money chip, top-right.
        frame:
            background "hud_chip_small"
            xpos config.screen_width - 40
            xanchor 1.0
            ypos 40
            xsize 220
            ysize 90
            padding (24, 0, 24, 0)

            hbox:
                yalign 0.5
                spacing 12

                add "icon_yen" at Transform(zoom=1.4) yalign 0.5
                text "[player_money]" size 32 color "#FFFFFF" bold True yalign 0.5


## Make the HUD a standard overlay, shown automatically during gameplay
## interactions (and suppressed on the main menu by the `if not main_menu`
## check above).
init python:
    if "game_hud" not in config.overlay_screens:
        config.overlay_screens.append("game_hud")
