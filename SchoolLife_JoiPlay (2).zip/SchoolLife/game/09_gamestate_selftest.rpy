# 09_gamestate_selftest.rpy
# Same idea as the nav self-test: I can't launch the actual Ren'Py engine
# here to eyeball the HUD, so this asserts the derived-time math against
# known values, then gives you an interactive label to click through in the
# real engine and watch the HUD update live.

label gamestate_selftest:

    python:
        _saved_minutes = game_minutes
        _saved_flags = (has_eaten, has_showered, has_dressed)

        # Start-of-game values.
        game_minutes = 420
        assert get_current_day() == 1, get_current_day()
        assert get_current_hour() == 7
        assert get_current_minute() == 0
        assert get_time_of_day() == "Morning"
        assert format_clock() == "7:00 AM", format_clock()

        # Just before midnight, still day 1.
        game_minutes = 1439
        assert get_current_day() == 1
        assert format_clock() == "11:59 PM", format_clock()

        # Exactly at the day boundary -> day 2, Night bucket.
        game_minutes = 1440
        assert get_current_day() == 2
        assert format_clock() == "12:00 AM", format_clock()
        assert get_time_of_day() == "Night"

        # advance_time() should reset daily flags only when the day changes.
        game_minutes = 1400   # Day 1, 11:20 PM
        has_eaten = has_showered = has_dressed = True

        advance_time(10)      # still day 1 (1410) -- flags should NOT reset
        assert get_current_day() == 1
        assert (has_eaten, has_showered, has_dressed) == (True, True, True)

        advance_time(50)      # crosses into day 2 (1460) -- flags SHOULD reset
        assert get_current_day() == 2
        assert (has_eaten, has_showered, has_dressed) == (False, False, False)

        # restore whatever the real game state was before this test ran
        game_minutes = _saved_minutes
        has_eaten, has_showered, has_dressed = _saved_flags

    "Gamestate self-test passed: day math, clock formatting, and the daily-flag reset on day change all check out."

    return


## Interactive debug demo -- actually watch the HUD update live in-engine. ###
# Sets the daily flags True, then advances time in visible steps across a
# day boundary so you can confirm on screen that:
#   - the clock and day counter in the HUD update each step
#   - has_eaten/has_showered/has_dressed flip back to False right when the
#     day counter ticks over
#   - player_money is untouched by any of this

label gamestate_debug_demo:

    $ has_eaten = True
    $ has_showered = True
    $ has_dressed = True

    "Debug demo: flags set to True. Day [get_current_day()], [format_clock()], [get_time_of_day()]. Flags: eaten=[has_eaten], showered=[has_showered], dressed=[has_dressed]."

    $ advance_time(30)

    "Advanced 30 min. Day [get_current_day()], [format_clock()], [get_time_of_day()]. Flags: eaten=[has_eaten], showered=[has_showered], dressed=[has_dressed]."

    $ advance_time(600)

    "Advanced 10 hours. Day [get_current_day()], [format_clock()], [get_time_of_day()]. Flags: eaten=[has_eaten], showered=[has_showered], dressed=[has_dressed]."

    $ advance_time(600)

    "Advanced another 10 hours -- this should cross midnight into a new day. Day [get_current_day()], [format_clock()], [get_time_of_day()]. Flags: eaten=[has_eaten], showered=[has_showered], dressed=[has_dressed]."

    "Money untouched throughout: [player_money]."

    return
