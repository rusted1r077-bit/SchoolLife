# 03_test_scene.rpy
# Scope: dialogue/character rendering only. No street-view nav, no game-state
# variables, no real scripted content yet -- this just proves the pieces from
# 01_characters.rpy and 02_dialogue_gui.rpy work together.
#
# Jump here from the shell's dev/test menu (Prompt 1's Btn_Test equivalent),
# or use this label as Ren'Py's start label temporarily while testing:
#
#     label start:
#         jump dialogue_system_test

label dialogue_system_test:

    scene bg test_placeholder at bg_fit
    with dissolve

    show boya idle at sprite_left
    show girla idle at sprite_right
    with dissolve

    boya "Hey -- you're new here, right?"

    girla "Yeah, just transferred in. Still trying to find my way around."

    show boya happy at sprite_left
    boya "Ha, everyone gets lost the first week. I did too."

    show girla happy at sprite_right
    girla "Good to know it's not just me, then."

    menu:
        "Ask if she wants a tour?"

        "Yes":
            boya "Want me to show you around before class starts?"
            girla "That would actually be a huge help. Thank you."

        "No":
            boya "Well, if you ever need help finding a room, just ask."
            girla "I will. Thanks."

    boya "Anyway, welcome to the school."

    return
