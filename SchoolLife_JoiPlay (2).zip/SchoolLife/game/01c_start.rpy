# 01c_start.rpy
# THIS LABEL WAS MISSING BEFORE. Ren'Py requires a label named exactly
# "start" to exist -- clicking "Start" on the main menu jumps here, and
# without it the game errors out ("could not find label 'start'").
#
# Since the actual scripted content (door/shower/sleep sequences etc.) is
# explicitly out of scope for this step and the one before it, this boots
# into a simple dev hub linking to everything built and tested so far, so
# you can actually click through each piece in JoiPlay. Replace this with
# the real opening scene once scripted sequences are in scope.

label start:

    scene black
    with dissolve

    "School Life -- dev build. Nothing past this point is final content; this hub just links to what's been built so far."

    jump dev_hub

label dev_hub:

    call screen dev_hub_menu

    if _return == "dialogue_test":
        call dialogue_system_test
    elif _return == "apartment_nav":
        call apartment_explore
    elif _return == "nav_selftest":
        call apartment_nav_selftest
    elif _return == "gamestate_selftest":
        call gamestate_selftest
    elif _return == "gamestate_demo":
        call gamestate_debug_demo
    elif _return == "quit":
        return

    jump dev_hub


screen dev_hub_menu():

    frame:
        background "gui/textbox.png"
        xalign 0.5
        yalign 0.5
        xsize 900
        ysize 700
        padding (60, 50, 60, 50)

        vbox:
            spacing 20

            text "Dev Hub" size 44 color "#FFFFFF" bold True
            text "Day [get_current_day()]  |  [format_clock()]  |  [get_time_of_day()]  |  ¥[player_money]" size 26 color "#CCCCCC"

            null height 20

            textbutton "Dialogue / character test scene":
                text_size 30
                text_color "#FFFFFF"
                action Return("dialogue_test")

            textbutton "Apartment navigation (Bedroom start)":
                text_size 30
                text_color "#FFFFFF"
                action Return("apartment_nav")

            textbutton "Run nav graph self-test":
                text_size 30
                text_color "#FFFFFF"
                action Return("nav_selftest")

            textbutton "Run gamestate self-test":
                text_size 30
                text_color "#FFFFFF"
                action Return("gamestate_selftest")

            textbutton "Gamestate/HUD debug demo (advance time)":
                text_size 30
                text_color "#FFFFFF"
                action Return("gamestate_demo")

            null height 10

            textbutton "Quit to main menu":
                text_size 30
                text_color "#FFB870"
                action Return("quit")
