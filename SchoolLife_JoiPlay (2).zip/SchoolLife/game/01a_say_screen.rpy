# 01a_say_screen.rpy
# THIS SCREEN WAS MISSING BEFORE. 02_dialogue_gui.rpy defined say_window /
# say_label / say_who / say_dialogue styles, but nothing ever used them --
# Ren'Py has no built-in "say" screen of its own, so without this, showing
# any dialogue line would have errored with "screen say is not known."
#
# Styles are set explicitly (style="say_who" / style="say_dialogue") rather
# than relying on Ren'Py's automatic style_prefix+id naming, since the id
# "what" would otherwise auto-resolve to "say_what", not the "say_dialogue"
# style name already defined in 02_dialogue_gui.rpy.

screen say(who, what):

    window:
        id "window"
        style "say_window"

        if who is not None:
            window:
                id "namebox"
                style "say_label"
                text who style "say_who"

        text what id "what" style "say_dialogue"
