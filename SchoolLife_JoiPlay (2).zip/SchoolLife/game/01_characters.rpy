# 01_characters.rpy
# Character() definitions and character images, ported from the Scratch
# 'School Life' project (VitaWapo). Display names below are placeholders --
# swap the "Boy A" etc. strings once real names are provided.

# ---- Character objects ----
# who_color tints the name in the namebox so each speaker is easy to tell
# apart at a glance; what_color keeps dialogue text a consistent white to
# match the dark textbox from the project shell.

define boya = Character(_("Boy A"), who_color="#8FB8FF", what_color="#FFFFFF")
define boyb = Character(_("Boy B"), who_color="#FFB870", what_color="#FFFFFF")
define boyc = Character(_("Boy C"), who_color="#8FE0B8", what_color="#FFFFFF")
define boyd = Character(_("Boy D"), who_color="#D6A0FF", what_color="#FFFFFF")
define girla = Character(_("Girl A"), who_color="#FF9EC4", what_color="#FFFFFF")
define girlb = Character(_("Girl B"), who_color="#FFE07A", what_color="#FFFFFF")

# ---- Character images ----
# Full expression sets were already available from the Scratch costumes, so
# they're all wired up now even though the test scene in this step only
# uses "idle" and "happy". One Ren'Py image per Scratch costume, e.g.
# "image boya happy" <- Char_BoyA's "Happy" costume.

# Char_BoyA
image boya idle = "characters/boya/idle.png"
image boya blush_annoyed = "characters/boya/blush_annoyed.png"
image boya blush_happy = "characters/boya/blush_happy.png"
image boya blush_suprised = "characters/boya/blush_suprised.png"
image boya bored = "characters/boya/bored.png"
image boya dark = "characters/boya/dark.png"
image boya evil_grin = "characters/boya/evil_grin.png"
image boya happy = "characters/boya/happy.png"
image boya hopeful = "characters/boya/hopeful.png"
image boya mad = "characters/boya/mad.png"
image boya nervous = "characters/boya/nervous.png"
image boya sad = "characters/boya/sad.png"
image boya silly = "characters/boya/silly.png"
image boya suprised = "characters/boya/suprised.png"

# Char_BoyB
image boyb idle = "characters/boyb/idle.png"
image boyb blush_annoyed = "characters/boyb/blush_annoyed.png"
image boyb blush_happy = "characters/boyb/blush_happy.png"
image boyb blush_hopeful = "characters/boyb/blush_hopeful.png"
image boyb blush_neutral = "characters/boyb/blush_neutral.png"
image boyb blush_sad = "characters/boyb/blush_sad.png"
image boyb blush_suprised = "characters/boyb/blush_suprised.png"
image boyb bored = "characters/boyb/bored.png"
image boyb happy = "characters/boyb/happy.png"
image boyb hopeful = "characters/boyb/hopeful.png"
image boyb mad = "characters/boyb/mad.png"
image boyb nervous = "characters/boyb/nervous.png"
image boyb sad = "characters/boyb/sad.png"
image boyb silly = "characters/boyb/silly.png"
image boyb suprised = "characters/boyb/suprised.png"

# Char_BoyC
image boyc idle = "characters/boyc/idle.png"
image boyc bored = "characters/boyc/bored.png"
image boyc dark = "characters/boyc/dark.png"
image boyc happy = "characters/boyc/happy.png"
image boyc hopeful = "characters/boyc/hopeful.png"
image boyc mad = "characters/boyc/mad.png"
image boyc sad = "characters/boyc/sad.png"
image boyc silly = "characters/boyc/silly.png"
image boyc suprised = "characters/boyc/suprised.png"

# Char_BoyD
image boyd idle = "characters/boyd/idle.png"
image boyd happy = "characters/boyd/happy.png"
image boyd hopeful = "characters/boyd/hopeful.png"
image boyd mad = "characters/boyd/mad.png"
image boyd sad = "characters/boyd/sad.png"
image boyd silly = "characters/boyd/silly.png"
image boyd suprised = "characters/boyd/suprised.png"

# Char_GirlA
image girla idle = "characters/girla/idle.png"
image girla blush_annoyed = "characters/girla/blush_annoyed.png"
image girla blush_happy = "characters/girla/blush_happy.png"
image girla blush_sad = "characters/girla/blush_sad.png"
image girla blush_suprised = "characters/girla/blush_suprised.png"
image girla bored = "characters/girla/bored.png"
image girla happy = "characters/girla/happy.png"
image girla hopeful = "characters/girla/hopeful.png"
image girla mad = "characters/girla/mad.png"
image girla sad = "characters/girla/sad.png"
image girla silly = "characters/girla/silly.png"
image girla suprised = "characters/girla/suprised.png"

# Char_GirlB
image girlb idle = "characters/girlb/idle.png"
image girlb blush_annoyed = "characters/girlb/blush_annoyed.png"
image girlb blush_crying = "characters/girlb/blush_crying.png"
image girlb blush_happy = "characters/girlb/blush_happy.png"
image girlb blush_sad = "characters/girlb/blush_sad.png"
image girlb blush_suprised = "characters/girlb/blush_suprised.png"
image girlb bored = "characters/girlb/bored.png"
image girlb happy = "characters/girlb/happy.png"
image girlb mad = "characters/girlb/mad.png"
image girlb nervous = "characters/girlb/nervous.png"
image girlb sad = "characters/girlb/sad.png"
image girlb silly = "characters/girlb/silly.png"
image girlb suprised = "characters/girlb/suprised.png"
