# 02_dialogue_gui.rpy
# Dialogue box, name box, and choice-menu styling for School Life.
#
# ASSUMPTION FLAGGED: these sizes/positions assume the project shell (Prompt 1)
# is running at Ren'Py's common default resolution, 1920x1080. If the shell set
# a different config.screen_width/height, scale the numbers below by the same
# ratio (or tell me the resolution and I'll fix it directly).
#
# The source Scratch art (textbox/namebox/buttons) was drawn for Scratch's
# 480x360 stage, so everything here is displayed at 3x its native pixel size
# to sit correctly on a 1080p canvas.

## Transforms for character sprites and background ##################

transform sprite_left:
    zoom 3.0
    xalign 0.22
    yalign 1.0

transform sprite_right:
    zoom 3.0
    xalign 0.78
    yalign 1.0

transform sprite_center:
    zoom 3.0
    xalign 0.5
    yalign 1.0

transform bg_fit:
    # Scales the 480x360 Scratch background up 3x (to 1440x1080), preserving
    # aspect ratio, centered on a 1920x1080 canvas.
    zoom 3.0
    xalign 0.5
    yalign 1.0

## Name box + dialogue box (dark, semi-transparent, rounded, white text) #####

style say_window:
    xsize 1320
    ysize 300
    xalign 0.5
    yalign 1.0
    yoffset -20
    background Transform("gui/textbox.png", zoom=3.0)
    padding (60, 50, 60, 40)

style say_label:
    xpos 90
    ypos -36
    xanchor 0.0
    background Transform("gui/namebox.png", zoom=3.0)
    padding (36, 12, 36, 12)
    xminimum 300
    ysize 100

style say_who:
    size 34
    bold True
    outlines [(2, "#1A1424", 0, 0)]
    # who_color set per-Character() in 01_characters.rpy handles the actual
    # per-speaker tint; this is just the fallback/base look.
    color "#FFFFFF"

style say_dialogue:
    size 32
    color "#FFFFFF"
    outlines [(1, "#00000080", 0, 2)]
    line_spacing 6
    xsize 1180


## Yes/No + general choice menu: purple pill buttons, matching main menu ####

style choice_button:
    background Frame("gui/pill_idle.png", 40, 40)
    hover_background Frame("gui/pill_hover.png", 40, 40)
    xsize 460
    ysize 100
    xalign 0.5
    padding (0, 0, 0, 0)

style choice_button_text:
    size 34
    bold True
    color "#7E5ECE"
    hover_color "#5A3FA0"
    text_align 0.5
    xalign 0.5
    yalign 0.5

# Vertical stack of pill buttons, centered -- this is what both the classic
# renpy.call_screen("choice", ...) two-option "Yes/No" prompts and any longer
# menu.() choice lists use, so the style automatically matches the main
# menu's purple pill look anywhere a choice comes up.
screen choice(items):
    style_prefix "choice"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 24

        for i in items:
            textbutton i.caption action i.action
